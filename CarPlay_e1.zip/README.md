[![EAS Build](https://github.com/yunghog/carplay-actions/actions/workflows/main.yml/badge.svg)](https://github.com/yunghog/carplay-actions/actions/workflows/main.yml)
[![Run Tests](https://github.com/yunghog/carplay-actions/actions/workflows/test.yml/badge.svg)](https://github.com/yunghog/carplay-actions/actions/workflows/test.yml)
